"""Bounded, same-host HTTP transport for authorized passive audits."""

import time
from urllib.parse import urljoin, urlparse

import requests

try:
    from .config import REQUEST_TIMEOUT, USER_AGENT
except ImportError:  # direct `python main.py` execution
    from config import REQUEST_TIMEOUT, USER_AGENT


class ScopeError(ValueError):
    """URL is not part of the configured target host and port."""


class RequestBudgetExceeded(RuntimeError):
    """The maximum number of HTTP requests has been reached."""


class ResponseSizeExceeded(RuntimeError):
    """Response exceeded the configured byte ceiling."""


class ScopedRequester:
    """Use only the target host, a bounded request budget, and manual redirects.

    Host/port checks limit accidental scope expansion. They are not a substitute
    for network-level egress controls, DNS pinning or SSRF protection.
    """

    def __init__(self, target, *, timeout=REQUEST_TIMEOUT, max_requests=80,
                 max_response_bytes=2_000_000, delay=0, max_redirects=5,
                 session=None):
        parsed = urlparse(target)
        if parsed.scheme not in {"http", "https"} or not parsed.hostname:
            raise ValueError("Target must be an absolute http(s) URL")
        if parsed.username or parsed.password:
            raise ValueError("Credentials in target URL are not supported")
        if max_requests < 1 or max_response_bytes < 1 or timeout <= 0 or delay < 0:
            raise ValueError("Invalid request limits")
        self.target = target
        self.hostname = parsed.hostname.lower()
        self.target_scheme = parsed.scheme
        self.explicit_port = parsed.port
        self.timeout = timeout
        self.max_requests = max_requests
        self.max_response_bytes = max_response_bytes
        self.delay = delay
        self.max_redirects = max_redirects
        self.requests_made = 0
        self.blocked_redirects = 0
        self.session = session or requests.Session()
        self.session.headers.update({"User-Agent": USER_AGENT})

    @property
    def budget_exhausted(self):
        return self.requests_made >= self.max_requests

    def in_scope(self, url):
        try:
            parsed = urlparse(url)
            port = parsed.port
        except ValueError:
            return False
        if (parsed.scheme not in {"http", "https"} or not parsed.hostname
                or parsed.username or parsed.password
                or parsed.hostname.lower() != self.hostname):
            return False
        # An HTTPS audit must not silently downgrade to cleartext HTTP.
        if self.target_scheme == "https" and parsed.scheme != "https":
            return False
        effective_port = port or (443 if parsed.scheme == "https" else 80)
        if self.explicit_port is not None:
            return effective_port == self.explicit_port
        return effective_port in {80, 443}

    def get(self, url):
        return self._request("GET", url)

    def post(self, url, data):
        return self._request("POST", url, data=data)

    def _request(self, method, url, data=None):
        for redirect_count in range(self.max_redirects + 1):
            if not self.in_scope(url):
                raise ScopeError(f"Out-of-scope URL blocked: {url}")
            if self.budget_exhausted:
                raise RequestBudgetExceeded(f"Request budget of {self.max_requests} exhausted")
            if self.delay:
                time.sleep(self.delay)
            self.requests_made += 1
            response = self.session.request(
                method, url, data=data, timeout=self.timeout,
                allow_redirects=False, stream=True,
            )
            try:
                header_length = response.headers.get("Content-Length")
                try:
                    declared_length = int(header_length) if header_length else 0
                except ValueError:
                    declared_length = 0
                if declared_length > self.max_response_bytes:
                    raise ResponseSizeExceeded(f"Response too large: {url}")
                body = bytearray()
                for chunk in response.iter_content(chunk_size=16_384):
                    if chunk:
                        body.extend(chunk)
                    if len(body) > self.max_response_bytes:
                        raise ResponseSizeExceeded(f"Response too large: {url}")
                response._content = bytes(body)
                response._content_consumed = True
            finally:
                response.close()

            if response.status_code not in (301, 302, 303, 307, 308):
                return response
            location = response.headers.get("Location")
            if not location:
                return response
            next_url = urljoin(url, location)
            if not self.in_scope(next_url):
                self.blocked_redirects += 1
                return response  # Record redirect, never contact outside host.
            if redirect_count == self.max_redirects:
                return response
            if response.status_code == 303 or (response.status_code in (301, 302) and method == "POST"):
                method, data = "GET", None
            url = next_url
        return response
