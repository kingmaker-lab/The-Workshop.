"""Offline regression tests: never contact a real host."""

import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

import requests

from analysis.http import analyze_response, detect_anomalies
from analysis.findings import findings_from_anomalies
from discovery import discover, extract_metadata_urls
from exporter import export_json
from models import Page
from requester import ScopedRequester, ScopeError, RequestBudgetExceeded, ResponseSizeExceeded


class FakeSession:
    def __init__(self, replies):
        self.replies = replies
        self.calls = []
        self.headers = {}

    def request(self, method, url, **kwargs):
        self.calls.append((method, url, kwargs))
        status, headers, body = self.replies[url]
        response = requests.Response()
        response.status_code = status
        response.headers.update(headers)
        response._content = body.encode() if isinstance(body, str) else body
        response._content_consumed = True
        response.url = url
        return response


def mkresponse(body="ok", content_type="text/plain", status=200):
    response = requests.Response()
    response.status_code = status
    response.headers["Content-Type"] = content_type
    response._content = body.encode() if isinstance(body, str) else body
    response._content_consumed = True
    return response


class TransportTests(unittest.TestCase):
    def test_blocks_external_request_before_network(self):
        session = FakeSession({})
        client = ScopedRequester("https://example.test/", session=session)
        with self.assertRaises(ScopeError):
            client.get("https://external.test/")
        self.assertEqual(session.calls, [])

    def test_blocks_external_redirect(self):
        session = FakeSession({
            "https://example.test/": (302, {"Location": "https://other.test/private"}, "moved"),
        })
        client = ScopedRequester("https://example.test/", session=session)
        response = client.get("https://example.test/")
        self.assertEqual(response.status_code, 302)
        self.assertEqual(client.blocked_redirects, 1)
        self.assertEqual(len(session.calls), 1)

    def test_follows_same_host_redirect(self):
        session = FakeSession({
            "https://example.test/": (302, {"Location": "/home"}, ""),
            "https://example.test/home": (200, {}, "hello"),
        })
        client = ScopedRequester("https://example.test/", session=session)
        self.assertEqual(client.get("https://example.test/").text, "hello")
        self.assertEqual(client.requests_made, 2)

    def test_budget_enforced(self):
        session = FakeSession({"https://example.test/": (200, {}, "ok")})
        client = ScopedRequester("https://example.test/", max_requests=1, session=session)
        client.get("https://example.test/")
        with self.assertRaises(RequestBudgetExceeded):
            client.get("https://example.test/")
        self.assertEqual(len(session.calls), 1)

    def test_response_limit_enforced(self):
        session = FakeSession({"https://example.test/": (200, {}, "abcdef")})
        client = ScopedRequester("https://example.test/", max_response_bytes=5, session=session)
        with self.assertRaises(ResponseSizeExceeded):
            client.get("https://example.test/")

    def test_https_downgrade_blocked(self):
        client = ScopedRequester("https://example.test/")
        self.assertFalse(client.in_scope("http://example.test/"))

    def test_port_confined(self):
        client = ScopedRequester("http://localhost:8123/")
        self.assertTrue(client.in_scope("http://localhost:8123/a"))
        self.assertFalse(client.in_scope("http://localhost:8124/a"))
        self.assertFalse(client.in_scope("http://localhost.evil.test:8123/"))


class DiscoveryTests(unittest.TestCase):
    def test_robots_disallow_not_discovered(self):
        value = extract_metadata_urls(
            "https://example.test/robots.txt",
            "User-agent: *\nDisallow: /admin\nAllow: /public\nSitemap: /sitemap.xml\n",
        )
        self.assertEqual(value, ["https://example.test/sitemap.xml"])

    def test_skip_external_js_fetch(self):
        target = "https://example.test/"
        replies = {
            target: (200, {"Content-Type": "text/html"},
                     '<html><script src="https://cdn.other.test/bundle.js"></script>'
                     '<script src="/app.js"></script></html>'),
            target + "robots.txt": (404, {}, ""),
            target + "sitemap.xml": (404, {}, ""),
            target + "manifest.json": (404, {}, ""),
            target + "app.js": (200, {"Content-Type": "application/javascript"},
                                 'fetch("/api/items")'),
            target + "api/items": (200, {"Content-Type": "application/json"}, '{}'),
        }
        session = FakeSession(replies)
        client = ScopedRequester(target, max_requests=10, session=session)
        pages, forms, endpoints = discover(target, requester={
            "get": client.get,
            "in_scope": client.in_scope,
            "budget_exhausted": lambda: client.budget_exhausted,
        }, max_pages=3)
        urls = [url for _, url, _ in session.calls]
        self.assertNotIn("https://cdn.other.test/bundle.js", urls)
        self.assertIn(target + "app.js", urls)
        self.assertTrue(any(e.url == target + "api/items" for e in endpoints))


class FindingsTests(unittest.TestCase):
    def test_duplicate_404_ignored(self):
        obs = analyze_response(mkresponse("no", status=404))
        pages = [Page("https://x.test/a", 404, "text/plain", 2, obs),
                 Page("https://x.test/b", 404, "text/plain", 2, obs)]
        self.assertEqual(detect_anomalies(pages), [])

    def test_duplicate_html_is_informational_spa_candidate(self):
        obs = analyze_response(mkresponse("<html>app</html>", "text/html"))
        pages = [Page("https://x.test/a", 200, "text/html", 16, obs),
                 Page("https://x.test/b", 200, "text/html", 16, obs)]
        anomalies = detect_anomalies(pages)
        self.assertEqual(anomalies[0].kind, "shared-html-response")
        finding = findings_from_anomalies(anomalies)[0]
        self.assertEqual(finding.severity, "info")
        self.assertEqual(finding.confidence, "medium")

    def test_json_report_has_summary(self):
        client = ScopedRequester("https://example.test/")
        with TemporaryDirectory() as tmp:
            output = export_json(Path(tmp) / "result.json", target=client.target,
                                 pages=[], forms=[], endpoints=[], anomalies=[],
                                 findings=[], requester=client)
            report = json.loads(output.read_text(encoding="utf-8"))
        self.assertEqual(report["mode"], "passive")
        self.assertEqual(report["summary"]["requests_made"], 0)

    def test_query_values_redacted_in_report(self):
        client = ScopedRequester("https://example.test/")
        page = Page("https://example.test/?token=secret123", 200, "text/plain", 2)
        with TemporaryDirectory() as tmp:
            output = export_json(Path(tmp) / "result.json", target=page.url,
                                 pages=[page], forms=[], endpoints=[], anomalies=[],
                                 findings=[], requester=client)
            data = output.read_text(encoding="utf-8")
        self.assertNotIn("secret123", data)
        self.assertIn("token=", data)


if __name__ == "__main__":
    unittest.main()
