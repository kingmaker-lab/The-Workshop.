# HTTP Auditor v0.2

**Web Attack Surface Discovery · Scoped HTTP Reconnaissance · Evidence-Based Anomaly Analysis**

Ferramenta modular de auditoria HTTP em Python que descobre páginas, formulários, endpoints e rotas JavaScript, caracteriza respostas e produz achados **informativos**. A versão 0.2 enfatiza controle de escopo, execução limitada e evidências exportáveis.

> **Status:** reconhecimento HTTP sem payloads de exploração. Os módulos `analyzer.py`, `validator.py` e `payloads.py` são experimentais e **não fazem parte do fluxo de execução**.

## O que faz

- Descobre links, formulários, campos, parâmetros de consulta e rotas referenciadas no HTML e em JavaScript (`fetch`, `axios`, XHR).
- Consulta `robots.txt`, `sitemap.xml` e `manifest.json` e registra recursos relacionados. Diretivas `Allow` e `Disallow` **não** são tratadas como URLs a serem visitadas.
- Organiza endpoints em categorias (`page`, `api`, `form`, `resource`, `static`, `document` etc.) com proveniência e confiança da descoberta.
- Inspeciona status, `Content-Type`, headers, atributos dos cookies e SHA-256 do corpo HTTP.
- Identifica respostas com tipo de mídia inesperado e recursos com corpos idênticos. HTML idêntico em múltiplas rotas é categorizado como **possível fallback SPA/soft-404**, não uma vulnerabilidade comprovada.
- Oferece limite global de requisições, tamanho máximo de resposta, atraso opcional e bloqueio de requisições fora do host/porta autorizados, inclusive após redirects.
- Exporta um relatório JSON contendo observações, anomalias, achados e contadores; valores de parâmetros nas URLs são mascarados no arquivo.

## Organização

```text
http-auditor-v0.2/
├── main.py                    # CLI de análise passiva
├── config.py                  # User Agent e configurações padrão
├── requester.py               # Transporte limitado ao escopo
├── discovery.py               # Crawl, formulários, rotas e evidências
├── javascript.py              # Extração heurística de rotas
├── models.py                  # Dataclasses e tipos
├── reporter.py                # Saída no terminal
├── exporter.py                # Relatório JSON
├── analyzer.py                # Módulo experimental, não ativado
├── validator.py               # Módulo experimental, não ativado
├── payloads.py                # Módulo experimental, não ativado
├── analysis/
│   ├── __init__.py
│   ├── classifier.py
│   ├── content.py
│   ├── findings.py
│   └── http.py
├── tests/
│   └── test_auditor.py
├── requirements.txt
└── ROADMAP.md
```

## Requisitos e instalação

Python 3.10+ é recomendado.

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

## Utilização

Informe expressamente a URL de um sistema próprio ou dentro de um escopo de auditoria autorizado:

```bash
python main.py https://app.example.org/
```

Salve um relatório estruturado, com limites explícitos:

```bash
python main.py https://app.example.org/ \
  --max-pages 30 \
  --max-requests 80 \
  --max-bytes 2000000 \
  --timeout 10 \
  --delay 0.2 \
  --json reports/audit.json
```

Argumentos disponíveis:

| Opção | Padrão | Significado |
|---|---:|---|
| `target` | obrigatório | URL autorizada, com `http://` ou `https://` |
| `--max-pages` | 30 | Limite de páginas no crawler principal |
| `--max-requests` | 80 | Limite global de requisições HTTP, incluindo redirecionamentos e JS |
| `--max-bytes` | 2000000 | Máximo de bytes de corpo por resposta (descompactada) |
| `--timeout` | 10 | Timeout por requisição, em segundos |
| `--delay` | 0 | Pausa em segundos antes de cada requisição |
| `--json FILE` | nenhum | Salva relatório de evidências em JSON |

**Importante:** `MAX_PAGES` sozinho não limita o total de requisições; use `--max-requests` para o teto global. Uma auditoria que esgota o orçamento pode produzir resultados incompletos.

## Executar testes (sem Internet)

```bash
python -m unittest discover -s tests -v
python -m compileall -q .
```

Os testes usam respostas simuladas; não acionam domínios reais. Cobrem escopo, redirects, orçamento de requisições, limites de resposta, análise de anomalias e exportação JSON.

## Semântica dos resultados

1. **Endpoint descoberto**: URL sugerida por link, metadado ou JavaScript; não significa que a rota foi validada.
2. **Observação HTTP**: resposta recebida e caracterizada.
3. **Anomalia**: comportamento que merece inspeção, como `content-type-mismatch` ou uma resposta idêntica em diferentes caminhos.
4. **Achado informativo**: registro estruturado com categoria, evidências e confiança; **não comprova vulnerabilidade explorável**.

O fingerprint SHA-256 é calculado sobre o **corpo da resposta**, não sobre headers ou URL. A classificação `shared-html-response` indica possível fallback SPA ou soft-404 e requer verificação manual.

## Restrições e riscos conhecidos

- Restringe por **host/porta** na camada HTTP. Não implementa pinagem DNS, validação de IP de destino nem políticas de egress de rede; não é um controle SSRF completo.
- Por padrão não segue redirecionamentos externos nem busca scripts de terceiros. Links externos podem aparecer como candidatos de descoberta.
- Um audit de `https://` não será redirecionado automaticamente para `http://`.
- A extração JavaScript é baseada em padrões estáticos: não interpreta código dinâmico nem autentica no navegador.
- Requisições GET podem ter efeitos colaterais em aplicações incorretamente implementadas. "Passivo" significa sem payloads de exploração, não ausência de tráfego.
- O JSON oculta valores dos parâmetros de URLs, mas paths, nomes de parâmetros, headers de observação e outros metadados ainda podem ser confidenciais. **Não publique relatórios reais sem revisão.**
- Não há confirmação de SQLi, XSS, LFI ou RCE; os módulos experimentais existem, mas não são ativados.

## Roadmap

Consulte [ROADMAP.md](ROADMAP.md). A próxima etapa sugerida (v0.3) inclui classificação de cabeçalhos/cookies, tratamento de falhas e relatórios mais completos, antes de qualquer validação ativa com autorização específica.

## Uso responsável e licença

Use apenas em sistemas de sua propriedade ou incluídos em um escopo explicitamente autorizado. `robots.txt` e sitemaps são fontes de informação, **não autorizações**. O repositório ainda não possui uma licença definida; adicione `LICENSE` antes de distribuí-lo como software livre.
