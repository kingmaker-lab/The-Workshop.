TARGET_URL = None  # Pass the authorized target explicitly via CLI

USER_AGENT = (
    "HTTP-Auditor/0.2 (+authorized passive security research)"
)

REQUEST_TIMEOUT = 10

MAX_PAGES = 30

SAME_DOMAIN_ONLY = True
