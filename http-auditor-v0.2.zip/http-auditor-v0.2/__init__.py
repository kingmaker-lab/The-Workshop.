"""Auditor package."""
