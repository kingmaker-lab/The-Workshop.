from dataclasses import dataclass, field
from enum import Enum
from typing import List


@dataclass
class Field:
    name: str
    input_type: str = "unknown"


@dataclass
class Parameter:
    name: str
    location: str
    input_type: str = "unknown"


class EndpointType(str, Enum):
    PAGE = "page"
    API = "api"
    FORM = "form"
    RESOURCE = "resource"
    STATIC = "static"
    DOCUMENT = "document"
    EXTERNAL = "external"
    UNKNOWN = "unknown"


@dataclass
class Form:
    action: str
    method: str
    external: bool = False
    fields: List[Field] = field(default_factory=list)


@dataclass
class Page:
    url: str
    status_code: int
    content_type: str
    size: int
    http_observation: "HTTPObservation | None" = None


@dataclass
class CookieObservation:
    name: str
    secure: bool = False
    httponly: bool = False
    samesite: str = ""


@dataclass
class HTTPObservation:
    status_code: int
    content_type: str
    content_length: int
    declared_type: str = ""
    fingerprint: str = ""
    headers: dict = field(default_factory=dict)
    cookies: List[CookieObservation] = field(default_factory=list)
    content: "ContentObservation | None" = None


@dataclass
class ContentObservation:
    kind: str = "unknown"
    detected_type: str = "unknown"
    valid: bool = False
    size: int = 0
    title: str = ""
    meta_generator: str = ""
    forms: int = 0
    scripts: int = 0
    links: int = 0
    framework_indicators: List[str] = field(default_factory=list)
    top_level_type: str = ""
    root_element: str = ""
    lines: int = 0
    directives: List[str] = field(default_factory=list)


@dataclass
class HTTPAnomaly:
    kind: str
    urls: List[str]
    message: str
    fingerprint: str = ""
    status_code: int = 0
    content_type: str = ""
    content_length: int = 0
    expected_content_type: str = ""
    expected_type: str = ""
    declared_type: str = ""
    detected_content_type: str = ""
    baseline_url: str = ""


@dataclass
class Finding:
    id: str
    category: str
    severity: str
    confidence: str
    title: str
    description: str
    endpoint: str
    evidence: List[str] = field(default_factory=list)
    references: List[str] = field(default_factory=list)


@dataclass(frozen=True)
class DiscoveryEvidence:
    source: str
    confidence: str = "medium"
    location: str = ""
    detail: str = ""


@dataclass
class Endpoint:
    url: str
    method: str = "GET"
    external: bool = False
    type: EndpointType = EndpointType.UNKNOWN
    parameters: List[Parameter] = field(default_factory=list)
    sources: List[str] = field(default_factory=list)
    evidence: List[DiscoveryEvidence] = field(default_factory=list)
    confidence: str = "medium"
    http_observation: "HTTPObservation | None" = None
    http_observation_reason: str = ""

    def add_evidence(self, item):
        evidence_key = (item.source, item.confidence, item.detail)
        existing_keys = {
            (evidence.source, evidence.confidence, evidence.detail)
            for evidence in self.evidence
        }
        if evidence_key not in existing_keys:
            self.evidence.append(item)
        if item.source not in self.sources:
            self.sources.append(item.source)

        confidence_rank = {"low": 0, "medium": 1, "high": 2}
        if confidence_rank.get(item.confidence, 1) > confidence_rank.get(self.confidence, 1):
            self.confidence = item.confidence

    def add_parameter(self, parameter):
        if any(
            existing.name == parameter.name
            and existing.location == parameter.location
            for existing in self.parameters
        ):
            return
        self.parameters.append(parameter)

    @property
    def source(self):
        return self.sources[0] if self.sources else "unknown"

    @property
    def internal(self):
        return not self.external


@dataclass
class EndpointProfile:
    endpoint: Endpoint
    status_code: int
    content_type: str
    size: int
    redirected: bool = False
    authentication_required: bool = False


@dataclass
class ActiveFinding:
    vuln_type: str
    url: str
    method: str
    parameter: str
    payload: str
    status_code: int
    response_size: int
    confidence: str
    evidence: str
    validation: str = "candidate"


@dataclass
class AttackSurface:
    pages: List[Page] = field(default_factory=list)
    forms: List[Form] = field(default_factory=list)


@dataclass
class Candidate:
    vuln_type: str
    method: str
    url: str
    parameter: str
    payload: str
    baseline: dict
    compared: dict


@dataclass
class ValidationResult:
    status: str
    reason: str
    confidence: str = "medium"
