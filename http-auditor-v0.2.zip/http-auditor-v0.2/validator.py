try:
    from .models import Candidate, ValidationResult
except ImportError:  # pragma: no cover
    from models import Candidate, ValidationResult


def validate_candidate(baseline, compared, payload, vuln_type, method, url, parameter):
    baseline_status = baseline.get("status_code")
    compared_status = compared.get("status_code")
    baseline_size = baseline.get("size")
    compared_size = compared.get("size")
    baseline_text = str(baseline.get("text", "")).lower()
    compared_text = str(compared.get("text", "")).lower()
    payload_lower = str(payload).lower()

    if baseline_status == compared_status and baseline_size == compared_size and baseline_text == compared_text:
        return ValidationResult(status="ignore", reason="no_relevant_change")

    if payload_lower in compared_text:
        return ValidationResult(
            status="candidate",
            reason="response_changed_and_reflected_payload",
            confidence="high",
        )

    if compared_status != baseline_status or compared_size != baseline_size:
        return ValidationResult(
            status="candidate",
            reason="response_changed_significantly",
            confidence="medium",
        )

    return ValidationResult(status="ignore", reason="no_evidence_of_payload_effect")
