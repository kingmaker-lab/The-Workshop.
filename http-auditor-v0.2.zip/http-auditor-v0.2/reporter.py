def print_surface(pages, forms, endpoints=None):
    if endpoints is None:
        endpoints = []

    endpoint_count = len(endpoints)
    internal_endpoints = sum(1 for item in endpoints if item.internal)
    parameterized_endpoints = sum(1 for item in endpoints if item.parameters)
    query_parameters = sum(
        sum(parameter.location == "query" for parameter in item.parameters)
        for item in endpoints
    )
    body_parameters = sum(
        sum(parameter.location == "body" for parameter in item.parameters)
        for item in endpoints
    )
    header_parameters = sum(
        sum(parameter.location == "header" for parameter in item.parameters)
        for item in endpoints
    )
    form_fields = sum(len(form.fields) for form in forms)
    external_endpoints = sum(1 for item in endpoints if item.external)
    type_counts = {}
    for endpoint in endpoints:
        endpoint_type = endpoint.type.value.upper()
        type_counts[endpoint_type] = type_counts.get(endpoint_type, 0) + 1

    print()
    print("=" * 70)
    print("                    ATTACK SURFACE")
    print("=" * 70)

    print()
    print(f"Pages discovered   : {len(pages)}")
    print(f"Forms discovered   : {len(forms)}")
    print(f"Endpoints          : {endpoint_count}")
    print(f"Internal endpoints : {internal_endpoints}")
    print(f"Parameterized      : {parameterized_endpoints}")
    print(f"Query parameters   : {query_parameters}")
    print(f"Body parameters    : {body_parameters}")
    print(f"Header parameters  : {header_parameters}")
    print(f"Form fields        : {form_fields}")
    print(f"External endpoints : {external_endpoints}")

    if type_counts:
        print()
        print("[RESOURCE TYPES]")
        for endpoint_type in ("PAGE", "API", "FORM", "RESOURCE", "STATIC", "DOCUMENT", "EXTERNAL", "UNKNOWN"):
            if endpoint_type in type_counts:
                print(f"{endpoint_type.capitalize():<19}: {type_counts[endpoint_type]}")

    if endpoints:
        print()
        print("[ENDPOINTS]")
        for endpoint in endpoints:
            marker = endpoint.type.value.upper()
            print(f"  [{marker:<8}] {endpoint.method:<4} {endpoint.url}")
            print(f"    Sources: {', '.join(endpoint.sources) or 'unknown'}")
            print(f"    Confidence: {endpoint.confidence}")
            for evidence in endpoint.evidence:
                detail = f" ({evidence.detail})" if evidence.detail else ""
                print(f"    Evidence: [{evidence.confidence}] {evidence.source}{detail}")
            if endpoint.parameters:
                print(
                    "    Parameters: "
                    + ", ".join(parameter.name for parameter in endpoint.parameters)
                )

    if forms:
        print()
        print("[FORMS]")

        for form in forms:
            marker = "[EXTERNAL]" if form.external else "[INTERNAL]"
            print(f"  {marker:<9} {form.method:<4}")
            print(f"    {form.action}")
            print("    Fields:")
            for field in form.fields:
                print(f"      - {field.name:<20} [{field.input_type}]")
    else:
        print()
        if parameterized_endpoints:
            print(
                f"[INFO] {parameterized_endpoints} endpoint(s) parametrizado(s) encontrado(s)."
            )
        else:
            print("[INFO] Nenhuma entrada parametrizada encontrada.")


def print_http_observations(pages, endpoints=None):
    print()
    print("=" * 70)
    print("                     HTTP OBSERVATIONS")
    print("=" * 70)

    for page in pages:
        observation = page.http_observation
        if observation is None:
            continue
        print()
        print(f"[HTTP] {page.url}")
        print(f"  Status: {observation.status_code}")
        print(f"  Content-Type: {observation.content_type or 'unknown'}")
        print(f"  Content-Length: {observation.content_length}")
        print(f"  Fingerprint: {observation.fingerprint}")
        if observation.content:
            print(
                f"  Content: {observation.content.detected_type} "
                f"(valid={observation.content.valid}, size={observation.content.size})"
            )
            if observation.content.title:
                print(f"  Title: {observation.content.title}")
            if observation.content.framework_indicators:
                print(f"  Frameworks: {', '.join(observation.content.framework_indicators)}")
        for name, value in observation.headers.items():
            print(f"  {name}: {value}")
        for cookie in observation.cookies:
            print(f"  Cookie: {cookie.name}")
            print(f"    Secure: {cookie.secure}")
            print(f"    HttpOnly: {cookie.httponly}")
            print(f"    SameSite: {cookie.samesite or 'missing'}")

    page_urls = {page.url for page in pages}
    for endpoint in endpoints or []:
        if endpoint.url in page_urls:
            continue
        observation = endpoint.http_observation
        print()
        print(f"[HTTP] {endpoint.method} {endpoint.url}")
        if observation is None:
            print("  Status: not requested")
            print(f"  Reason: {endpoint.http_observation_reason}")
            continue
        print(f"  Status: {observation.status_code}")
        print(f"  Content-Type: {observation.content_type or 'unknown'}")
        print(f"  Content-Length: {observation.content_length}")
        print(f"  Fingerprint: {observation.fingerprint}")
        if observation.content:
            print(
                f"  Content: {observation.content.detected_type} "
                f"(valid={observation.content.valid}, size={observation.content.size})"
            )
        for name, value in observation.headers.items():
            print(f"  {name}: {value}")


def print_http_anomalies(pages, endpoints=None):
    try:
        from .analysis.http import detect_anomalies
        from .analysis.classifier import classify_anomaly
    except ImportError:  # pragma: no cover
        from analysis.http import detect_anomalies
        from analysis.classifier import classify_anomaly

    anomalies = detect_anomalies(pages, endpoints)
    if not anomalies:
        return

    print()
    print("=" * 70)
    print("                       HTTP ANOMALIES")
    print("=" * 70)
    for anomaly in anomalies:
        print()
        print(f"[ANOMALY] {classify_anomaly(anomaly)}")
        print(f"  Observation: {anomaly.kind}")
        print(f"  {anomaly.message}")
        if anomaly.expected_content_type:
            print(f"  Expected: {anomaly.expected_content_type}")
            print(f"  Received: {anomaly.content_type or 'unknown'}")
            print(f"  Detected: {anomaly.detected_content_type or 'unknown'}")
        else:
            print(f"  Fingerprint: {anomaly.fingerprint}")
            print(f"  Baseline: {anomaly.baseline_url}")
            print(f"  Status: {anomaly.status_code}")
            print(f"  Content-Type: {anomaly.content_type or 'unknown'}")
            print(f"  Size: {anomaly.content_length}")
        print("  Affected URLs:")
        for url in anomaly.urls:
            print(f"    - {url}")


def print_findings(findings):
    if not findings:
        return
    print()
    print("=" * 70)
    print("                         FINDINGS")
    print("=" * 70)
    for finding in findings:
        print()
        print(f"[{finding.severity.upper()}] {finding.id}")
        print(f"  Category: {finding.category}")
        print(f"  Confidence: {finding.confidence}")
        print(f"  Title: {finding.title}")
        print(f"  Endpoint: {finding.endpoint}")
        print(f"  Description: {finding.description}")
        for evidence in finding.evidence:
            print(f"  Evidence: {evidence}")


def print_finding(finding):
    print()
    print("!" * 70)
    print("[!] POSSÍVEL ACHADO")
    print("!" * 70)

    print(f"Tipo       : {finding.vuln_type}")
    print(f"Confidence : {finding.confidence}")
    print(f"Method     : {finding.method}")
    print(f"Parameter  : {finding.parameter}")
    print(f"URL        : {finding.url}")
    print(f"HTTP       : {finding.status_code}")
    print(f"Size       : {finding.response_size} bytes")
    print(f"Payload    : {finding.payload}")
    print(f"Evidence   : {finding.evidence}")


def print_summary(total, findings, pages=None, forms=None, endpoints=None):
    print()
    print("=" * 70)
    print("                         SUMMARY")
    print("=" * 70)

    if pages is not None:
        print(f"Pages discovered   : {len(pages)}")
    if forms is not None:
        print(f"Forms discovered   : {len(forms)}")
        print(f"Form fields        : {sum(len(form.fields) for form in forms)}")
    if endpoints is not None:
        print(f"Endpoints discovered       : {len(endpoints)}")
        print(f"Internal endpoints         : {sum(1 for item in endpoints if item.internal)}")
        print(f"Parameterized endpoints    : {sum(1 for item in endpoints if item.parameters)}")
        print(f"External endpoints         : {sum(1 for item in endpoints if item.external)}")

    print(f"Active tests       : {total}")
    print(f"Possible findings  : {len(findings)}")

    if findings:
        print("[!] Achados encontrados. Validação manual necessária.")
    elif endpoints:
        parameterized_endpoints = sum(1 for item in endpoints if item.parameters)
        if parameterized_endpoints:
            print(f"[INFO] {parameterized_endpoints} endpoint(s) parametrizado(s) encontrado(s).")
        else:
            print("[INFO] Nenhum endpoint interno com parâmetros testáveis foi encontrado.")
    else:
        print("[INFO] Nenhuma superfície de entrada foi descoberta.")

    print("=" * 70)
