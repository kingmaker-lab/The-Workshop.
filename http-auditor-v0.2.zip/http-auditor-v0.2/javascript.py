import re
from urllib.parse import urljoin, urlparse


_ROUTE_PATTERNS = (
    re.compile(
        r'''(?:fetch|axios\.(?:get|post|put|patch|delete))\s*\(\s*["'`](?P<route>[^"'`]+)''',
        re.I,
    ),
    re.compile(
        r'''(?:XMLHttpRequest|\.open)\s*\([^,]*,\s*["'`](?P<route>[^"'`]+)''',
        re.I,
    ),
    re.compile(
        r'''(?:url|href)\s*[:=]\s*["'`](?P<route>[^"'`]+)''',
        re.I,
    ),
)

_API_PATTERN = re.compile(
    r'''["'`](?P<route>/(?:api|dados_leitor)/[^"'`\s<>]*)["'`]''',
    re.I,
)

_SOURCED_ROUTE_PATTERNS = (
    ("javascript.fetch", _ROUTE_PATTERNS[0]),
    ("javascript.xhr", _ROUTE_PATTERNS[1]),
    ("javascript.url", _ROUTE_PATTERNS[2]),
    ("javascript.api", _API_PATTERN),
)


def extract_js_route_candidates(content):
    return sorted({route for route, _ in extract_js_route_candidates_with_sources(content)})


def extract_js_route_candidates_with_sources(content):
    routes = {}
    for source, pattern in _SOURCED_ROUTE_PATTERNS:
        for match in pattern.finditer(content):
            route = match.group("route").strip()
            if route and not route.startswith("//"):
                routes.setdefault(route, source)
    return sorted(routes.items())


class JavaScriptDiscovery:
    def __init__(self, base_url):
        self.base_url = base_url

    def is_valid_route(self, value):
        return is_valid_js_route(value)

    def extract(self, javascript, source_url):
        routes = []
        for value in extract_js_route_candidates(javascript):
            if not self.is_valid_route(value):
                continue

            value = value.strip()
            absolute = urljoin(source_url, value)
            if is_valid_discovered_url(absolute):
                routes.append(absolute)
        return sorted(set(routes))


def is_valid_discovered_url(url):
    if not url or len(url) > 2048:
        return False

    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        return False

    suspicious_markers = (
        ");", "=>", "const ", "let ", "var ", "function ",
        "await ", "console.", "JSON.", "document.",
    )
    return not any(marker in url for marker in suspicious_markers)


def is_valid_js_route(value):
    if not value:
        return False

    value = value.strip()
    if len(value) > 512 or any(char in value for char in "\n\r\t{}();"):
        return False
    if "${" in value:
        return False

    lowered = value.lower()
    if lowered.startswith(("javascript:", "mailto:", "tel:", "data:", "blob:")):
        return False
    if lowered in {"_blank", "_self", "_parent", "_top", "null", "undefined", "true", "false"}:
        return False

    suspicious = (
        "const ", "let ", "var ", "function ", "return ",
        "console.", "document.", "window.", "json.", "=>",
    )
    if any(marker in lowered for marker in suspicious):
        return False
    return value.startswith(("/", "http://", "https://"))