"""Command-line entry point for bounded passive HTTP audits."""

import argparse

try:
    from .config import MAX_PAGES, REQUEST_TIMEOUT, TARGET_URL
    from .discovery import discover
    from .analysis.findings import findings_from_anomalies
    from .analysis.http import detect_anomalies
    from .reporter import print_findings, print_http_anomalies, print_http_observations, print_surface
    from .requester import ScopedRequester
    from .exporter import export_json
except ImportError:  # python main.py from repo root
    from config import MAX_PAGES, REQUEST_TIMEOUT, TARGET_URL
    from discovery import discover
    from analysis.findings import findings_from_anomalies
    from analysis.http import detect_anomalies
    from reporter import print_findings, print_http_anomalies, print_http_observations, print_surface
    from requester import ScopedRequester
    from exporter import export_json


def make_parser():
    parser = argparse.ArgumentParser(description="HTTP Auditor v0.2 — bounded passive discovery")
    parser.add_argument("target", nargs="?", default=TARGET_URL, help="Authorized target URL")
    parser.add_argument("--max-pages", type=int, default=MAX_PAGES, help="Crawler page budget")
    parser.add_argument("--max-requests", type=int, default=80, help="Global HTTP request budget")
    parser.add_argument("--max-bytes", type=int, default=2_000_000, help="Maximum decompressed response bytes")
    parser.add_argument("--timeout", type=float, default=REQUEST_TIMEOUT, help="HTTP timeout in seconds")
    parser.add_argument("--delay", type=float, default=0, help="Minimum delay before each request")
    parser.add_argument("--json", metavar="FILE", help="Save structured evidence report")
    return parser


def main(argv=None):
    args = make_parser().parse_args(argv)
    if args.max_pages < 1:
        make_parser().error("--max-pages must be >= 1")
    if not args.target:
        make_parser().error("an explicit authorized target URL is required")
    requester = ScopedRequester(
        args.target, timeout=args.timeout, max_requests=args.max_requests,
        max_response_bytes=args.max_bytes, delay=args.delay,
    )
    print("=" * 70)
    print("                         HTTP AUDITOR v0.2")
    print("=" * 70)
    print(f"Target: {args.target}")
    print("Mode  : passive (no vulnerability payloads)")
    print("\n[+] Iniciando discovery com limites globais...")

    pages, forms, endpoints = discover(args.target, requester={
        "get": requester.get,
        "post": requester.post,
        "in_scope": requester.in_scope,
        "budget_exhausted": lambda: requester.budget_exhausted,
    }, max_pages=args.max_pages)

    anomalies = detect_anomalies(pages, endpoints)
    findings = findings_from_anomalies(anomalies)
    print_surface(pages, forms, endpoints)
    print_http_observations(pages, endpoints)
    print_http_anomalies(pages, endpoints)
    print_findings(findings)
    print(f"\n[INFO] Requests: {requester.requests_made}/{requester.max_requests}; "
          f"blocked external redirects: {requester.blocked_redirects}")
    if requester.budget_exhausted:
        print("[WARN] Request limit reached; this audit is partial.")
    if args.json:
        path = export_json(
            args.json, target=args.target, pages=pages, forms=forms,
            endpoints=endpoints, anomalies=anomalies, findings=findings,
            requester=requester,
        )
        print(f"[INFO] Structured report: {path}")
    print("[INFO] Testes ativos permanecem desabilitados.")


if __name__ == "__main__":
    main()
