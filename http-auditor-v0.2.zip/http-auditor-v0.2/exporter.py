"""Machine-readable reports without network access or active probes."""

import json
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit


def _redact_url_values(value):
    """Keep parameter names for evidence while excluding secrets in query values."""
    if isinstance(value, dict):
        return {key: _redact_url_values(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_redact_url_values(item) for item in value]
    if isinstance(value, str) and value.startswith(("http://", "https://", "/")):
        parsed = urlsplit(value)
        if parsed.query:
            query = urlencode([(key, "[REDACTED]") for key, _ in parse_qsl(parsed.query, keep_blank_values=True)])
            return urlunsplit(parsed._replace(query=query))
    return value


def export_json(path, *, target, pages, forms, endpoints, anomalies, findings, requester):
    data = {
        "schema_version": "0.2",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "target": target,
        "mode": "passive",
        "summary": {
            "pages": len(pages),
            "forms": len(forms),
            "endpoints": len(endpoints),
            "anomalies": len(anomalies),
            "findings": len(findings),
            "requests_made": requester.requests_made,
            "max_requests": requester.max_requests,
            "blocked_redirects": requester.blocked_redirects,
            "request_budget_exhausted": requester.budget_exhausted,
        },
        "pages": [asdict(page) for page in pages],
        "forms": [asdict(form) for form in forms],
        "endpoints": [asdict(endpoint) for endpoint in endpoints],
        "anomalies": [asdict(anomaly) for anomaly in anomalies],
        "findings": [asdict(finding) for finding in findings],
    }
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(_redact_url_values(data), indent=2, ensure_ascii=False), encoding="utf-8")
    return output
