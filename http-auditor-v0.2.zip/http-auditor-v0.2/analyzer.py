try:
    from .models import ActiveFinding
except ImportError:  # pragma: no cover
    from models import ActiveFinding


def analyze(response, vuln_type, payload, url, method, parameter):
    content = response.text.lower()

    if vuln_type == "SQLi":
        indicators = {
            "sql syntax": "SQL syntax error",
            "mysql error": "MySQL error",
            "oracle error": "Oracle error",
            "postgresql error": "PostgreSQL error",
            "driver error": "Database driver error",
        }

        for indicator, evidence in indicators.items():
            if indicator in content:
                    return ActiveFinding(
                    vuln_type=vuln_type,
                    url=url,
                    method=method,
                    parameter=parameter,
                    payload=payload,
                    status_code=response.status_code,
                    response_size=len(response.content),
                    confidence="low",
                    evidence=evidence,
                )

    elif vuln_type == "XSS":
        if payload.lower() in content:
                return ActiveFinding(
                vuln_type=vuln_type,
                url=url,
                method=method,
                parameter=parameter,
                payload=payload,
                status_code=response.status_code,
                response_size=len(response.content),
                confidence="low",
                evidence="Payload refletido na resposta",
            )

    elif vuln_type == "LFI":
        indicators = [
            "root:x:0:0",
            "[extensions]",
            "/bin/bash",
        ]

        for indicator in indicators:
            if indicator in content:
                    return ActiveFinding(
                    vuln_type=vuln_type,
                    url=url,
                    method=method,
                    parameter=parameter,
                    payload=payload,
                    status_code=response.status_code,
                    response_size=len(response.content),
                    confidence="medium",
                    evidence=f"Indicador encontrado: {indicator}",
                )

    elif vuln_type == "RCE":
        indicators = [
            "uid=",
            "gid=",
            "directory of",
        ]

        for indicator in indicators:
            if indicator in content:
                    return ActiveFinding(
                    vuln_type=vuln_type,
                    url=url,
                    method=method,
                    parameter=parameter,
                    payload=payload,
                    status_code=response.status_code,
                    response_size=len(response.content),
                    confidence="medium",
                    evidence=f"Indicador encontrado: {indicator}",
                )

    return None
