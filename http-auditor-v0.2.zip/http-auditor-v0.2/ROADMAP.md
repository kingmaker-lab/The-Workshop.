# HTTP Auditor — Roadmap

## v0.1 — Passive discovery (original files)

- [x] HTML pages, forms and parameters
- [x] JavaScript route heuristics
- [x] Headers, cookies and SHA-256 response fingerprints
- [x] Informational HTTP anomaly findings

## v0.2 — Controlled discovery and evidence (this release)

- [x] Host and port scope enforced at HTTP transport layer
- [x] Redirects handled manually; off-scope redirects not followed
- [x] Explicit target required (no default live URL)
- [x] Global request budget and per-response byte ceiling
- [x] Optional delay and configurable crawler page limit
- [x] Treat robots.txt Allow/Disallow as directives, not URLs to visit
- [x] Do not fetch third-party scripts
- [x] Skip fingerprint collisions on non-2xx responses
- [x] Separate shared HTML responses from generic collisions
- [x] JSON evidence export; redact URL query parameter values
- [x] Offline regression tests

## v0.3 — Stronger passive coverage (proposed; not implemented)

- [ ] Improve URL canonicalization, queue deduplication, and root-path rules
- [ ] Classify assets and APIs more accurately by response and source
- [ ] Detect soft-404 with local baselines under an explicit opt-in
- [ ] Rate-limiting backoff, Retry-After, connection errors and structured logs
- [ ] HTTP security headers and cookie policy assessment with clear evidence
- [ ] Authentication support via explicit user-approved configuration
- [ ] SARIF/HTML reports and schema validation
- [ ] Run static security checks and CI test suite

## v0.4 — Authorized active validation (proposed; not implemented)

- [ ] Explicit `--active` opt-in, user-defined allowlist and dry-run plans
- [ ] Safe fixtures and validation stages to reduce false positives
- [ ] Controlled baseline comparisons per parameter and HTTP method
- [ ] Audit trail, request budget per finding, allowlisted methods
- [ ] No testing of live third-party assets or endpoints outside approved scope

> The repository currently performs passive reconnaissance with HTTP GET requests. "Passive" does not mean zero impact: any request can be logged, affect rate limits, or trigger poorly designed GET handlers. Use only on targets where permission exists.
