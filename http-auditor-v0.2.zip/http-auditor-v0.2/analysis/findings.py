try:
    from ..models import Finding
except ImportError:  # pragma: no cover
    from models import Finding


def findings_from_anomalies(anomalies):
    findings = []
    seen = set()
    for index, anomaly in enumerate(anomalies, start=1):
        if anomaly.kind == "content-type-mismatch":
            category = "resource-routing"
            title = "Expected resource returned with different content"
            endpoint = anomaly.urls[0]
            description = "The resource expectation, declared media type, and detected body type differ."
            evidence = [
                f"expected_type={anomaly.expected_type or anomaly.expected_content_type}",
                f"declared_type={anomaly.declared_type or anomaly.content_type}",
                f"detected_type={anomaly.detected_content_type or 'unknown'}",
                f"status={anomaly.status_code}",
            ]
        elif anomaly.kind in {"response-fingerprint-collision", "shared-html-response"}:
            is_html_fallback = anomaly.kind == "shared-html-response"
            category = "possible-spa-fallback" if is_html_fallback else "response-collision"
            title = (
                "Multiple routes return identical HTML (possible SPA fallback)"
                if is_html_fallback else "Multiple resources return an identical response"
            )
            endpoint = anomaly.baseline_url
            description = (
                "Identical HTML on several paths can be normal SPA routing or a soft-404."
                if is_html_fallback else
                "Distinct discovered resources share status, media type, size, and body fingerprint."
            )
            evidence = [
                f"baseline={anomaly.baseline_url}",
                f"fingerprint={anomaly.fingerprint}",
                f"status={anomaly.status_code}",
                f"content_type={anomaly.content_type}",
                f"content_length={anomaly.content_length}",
                f"affected_count={len(anomaly.urls)}",
            ]
        else:
            continue

        key = (category, endpoint, tuple(anomaly.urls))
        if key in seen:
            continue
        seen.add(key)
        findings.append(
            Finding(
                id=f"{category}-{index:03d}",
                category=category,
                severity="info",
                confidence="medium" if anomaly.kind == "shared-html-response" else "high",
                title=title,
                description=description,
                endpoint=endpoint,
                evidence=evidence,
            )
        )
    return findings