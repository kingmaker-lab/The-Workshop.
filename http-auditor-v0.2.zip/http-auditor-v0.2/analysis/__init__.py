"""HTTP observations and anomaly detection."""
