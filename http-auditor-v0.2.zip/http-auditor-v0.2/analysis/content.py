import json
import re
import xml.etree.ElementTree as ElementTree

from bs4 import BeautifulSoup

try:
    from ..models import ContentObservation
except ImportError:  # pragma: no cover
    from models import ContentObservation


def _decode(body):
    if isinstance(body, bytes):
        return body.decode("utf-8", errors="replace")
    return str(body)


def _analyze_html(text):
    soup = BeautifulSoup(text, "html.parser")
    indicators = []
    lowered = text.lower()
    for marker, name in (
        ("__next_data__", "next.js"),
        ("data-reactroot", "react"),
        ("ng-version", "angular"),
        ("__nuxt__", "nuxt"),
        ("data-v-", "vue"),
    ):
        if marker in lowered:
            indicators.append(name)
    generator = soup.find("meta", attrs={"name": re.compile("^generator$", re.I)})
    return ContentObservation(
        kind="html",
        detected_type="html",
        valid=True,
        size=len(text.encode("utf-8")),
        title=soup.title.get_text(strip=True) if soup.title else "",
        meta_generator=generator.get("content", "") if generator else "",
        forms=len(soup.find_all("form")),
        scripts=len(soup.find_all("script")),
        links=len(soup.find_all("a")),
        framework_indicators=indicators,
    )


def analyze_content(body, content_type=""):
    text = _decode(body)
    media_type = content_type.split(";", 1)[0].strip().lower()
    if media_type == "text/html" or re.search(r"<html\b|<!doctype\s+html", text, re.I):
        return _analyze_html(text)

    if "json" in media_type or text.lstrip().startswith(("{", "[")):
        try:
            value = json.loads(text)
            top_level_type = "array" if isinstance(value, list) else "object" if isinstance(value, dict) else type(value).__name__
            return ContentObservation(
                kind="json",
                detected_type="json",
                valid=True,
                size=len(text.encode("utf-8")),
                top_level_type=top_level_type,
            )
        except (TypeError, ValueError):
            return ContentObservation(
                kind="json",
                detected_type="json",
                valid=False,
                size=len(text.encode("utf-8")),
            )

    if "xml" in media_type or text.lstrip().startswith("<"):
        try:
            root = ElementTree.fromstring(text)
            return ContentObservation(
                kind="xml",
                detected_type="xml",
                valid=True,
                size=len(text.encode("utf-8")),
                root_element=root.tag,
            )
        except ElementTree.ParseError:
            return ContentObservation(
                kind="xml",
                detected_type="xml",
                valid=False,
                size=len(text.encode("utf-8")),
            )

    if media_type.startswith("text/") or not media_type:
        directives = [
            line.strip()
            for line in text.splitlines()
            if re.match(r"^(allow|disallow|sitemap|user-agent):", line, re.I)
        ]
        return ContentObservation(
            kind="text",
            detected_type="text",
            valid=True,
            size=len(text.encode("utf-8")),
            lines=len(text.splitlines()),
            directives=directives,
        )

    return ContentObservation(size=len(text.encode("utf-8")))