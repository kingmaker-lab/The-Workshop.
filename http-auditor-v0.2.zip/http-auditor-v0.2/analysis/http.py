from http.cookies import SimpleCookie
import hashlib
from collections import defaultdict
from urllib.parse import urlparse

try:
    from .content import analyze_content
except ImportError:  # pragma: no cover
    from analysis.content import analyze_content

try:
    from ..models import CookieObservation, HTTPAnomaly, HTTPObservation
except ImportError:  # pragma: no cover
    from models import CookieObservation, HTTPAnomaly, HTTPObservation


OBSERVED_HEADERS = (
    "Server",
    "X-Powered-By",
    "Location",
    "Cache-Control",
    "Content-Security-Policy",
    "Strict-Transport-Security",
    "X-Content-Type-Options",
    "X-Frame-Options",
    "Referrer-Policy",
    "Permissions-Policy",
    "Access-Control-Allow-Origin",
)


def _header_value(headers, name):
    for key, value in headers.items():
        if key.lower() == name.lower():
            return str(value)
    return ""


def _cookie_headers(response):
    raw_headers = getattr(getattr(response, "raw", None), "headers", None)
    if raw_headers is not None and hasattr(raw_headers, "get_all"):
        return raw_headers.get_all("Set-Cookie") or []

    value = _header_value(response.headers, "Set-Cookie")
    return [value] if value else []


def _parse_cookies(response):
    cookies = []
    for header in _cookie_headers(response):
        parsed = SimpleCookie()
        parsed.load(header)
        for name, morsel in parsed.items():
            cookies.append(
                CookieObservation(
                    name=name,
                    secure=bool(morsel["secure"]),
                    httponly=bool(morsel["httponly"]),
                    samesite=morsel["samesite"],
                )
            )
    return cookies


def analyze_response(response):
    headers = {
        name: value
        for name in OBSERVED_HEADERS
        if (value := _header_value(response.headers, name))
    }
    content_length = _header_value(response.headers, "Content-Length")
    try:
        content_length = int(content_length)
    except (TypeError, ValueError):
        content_length = len(response.content)

    return HTTPObservation(
        status_code=response.status_code,
        content_type=_header_value(response.headers, "Content-Type"),
        content_length=content_length,
        declared_type=_header_value(response.headers, "Content-Type").split(";", 1)[0].strip().lower(),
        fingerprint=response_fingerprint(response),
        headers=headers,
        cookies=_parse_cookies(response),
        content=analyze_content(
            response.content,
            _header_value(response.headers, "Content-Type"),
        ),
    )


def response_fingerprint(response):
    return hashlib.sha256(response.content).hexdigest()


def _expected_content_type(url):
    path = urlparse(url).path.lower()
    if path.endswith("/robots.txt"):
        return "text/plain"
    if path.endswith("/manifest.json"):
        return "application/json"
    if path.endswith("/sitemap.xml"):
        return "application/xml"
    return ""


def _content_type_matches(actual, expected):
    return actual.split(";", 1)[0].strip().lower() in {
        expected,
        "application/manifest+json" if expected == "application/json" else expected,
        "text/xml" if expected == "application/xml" else expected,
    }


def detect_anomalies(pages, endpoints=None):
    anomalies = []
    fingerprints = defaultdict(list)
    observed_by_url = {
        page.url: page.http_observation
        for page in pages
    }
    for endpoint in endpoints or []:
        observed_by_url.setdefault(endpoint.url, endpoint.http_observation)
    observed_resources = list(observed_by_url.items())
    for url, observation in observed_resources:
        if observation is None:
            continue
        fingerprints[
            (
                observation.status_code,
                observation.content_type,
                observation.content_length,
                observation.fingerprint,
            )
        ].append(url)

        expected = _expected_content_type(url)
        if (
            expected
            and observation.status_code == 200
            and not _content_type_matches(observation.content_type, expected)
        ):
            declared_type = observation.declared_type or observation.content_type.split(";", 1)[0].strip().lower()
            anomalies.append(
                HTTPAnomaly(
                    kind="content-type-mismatch",
                    urls=[url],
                    message="Response Content-Type does not match the expected resource type.",
                    status_code=observation.status_code,
                    content_type=observation.content_type,
                    content_length=observation.content_length,
                    expected_content_type=expected,
                    expected_type=expected,
                    declared_type=declared_type,
                    detected_content_type=(
                        observation.content.detected_type
                        if observation.content else "unknown"
                    ),
                )
            )

    for key, urls in fingerprints.items():
        if len(urls) < 2:
            continue
        status_code, content_type, content_length, fingerprint = key
        # Duplicate error bodies and redirects are expected on many sites.
        if status_code < 200 or status_code >= 300:
            continue
        baseline_url, *affected_urls = urls
        html_shell = "text/html" in content_type.lower()
        anomalies.append(
            HTTPAnomaly(
                kind="shared-html-response" if html_shell else "response-fingerprint-collision",
            urls=affected_urls,
                message=(
                    "Multiple routes share identical HTML; possible SPA fallback or soft-404 "
                    "(not a confirmed vulnerability)."
                    if html_shell else
                    "Multiple distinct resources returned the same HTTP response."
                ),
                fingerprint=fingerprint,
                status_code=status_code,
                content_type=content_type,
                content_length=content_length,
                baseline_url=baseline_url,
            )
        )

    return anomalies