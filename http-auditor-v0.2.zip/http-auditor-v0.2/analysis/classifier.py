ANOMALY_CATEGORIES = {
    "response-fingerprint-collision": "response-collision",
    "content-type-mismatch": "resource-routing-anomaly",
    "shared-html-response": "possible-spa-fallback",
}


def classify_anomaly(anomaly):
    return ANOMALY_CATEGORIES.get(anomaly.kind, "http-anomaly")