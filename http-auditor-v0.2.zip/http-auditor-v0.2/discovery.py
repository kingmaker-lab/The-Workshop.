import json
import re
from urllib.parse import parse_qs, urljoin, urlparse, urlunparse

from bs4 import BeautifulSoup

try:
    from .config import MAX_PAGES, SAME_DOMAIN_ONLY
    from .analysis.http import analyze_response
    from .javascript import (
        extract_js_route_candidates,
        extract_js_route_candidates_with_sources,
        is_valid_discovered_url,
        is_valid_js_route,
    )
    from .models import DiscoveryEvidence, Endpoint, EndpointType, Field, Form, Page, Parameter
except ImportError:  # pragma: no cover
    from config import MAX_PAGES, SAME_DOMAIN_ONLY
    from analysis.http import analyze_response
    from javascript import (
        extract_js_route_candidates,
        extract_js_route_candidates_with_sources,
        is_valid_discovered_url,
        is_valid_js_route,
    )
    from models import DiscoveryEvidence, Endpoint, EndpointType, Field, Form, Page, Parameter


def normalize_url(url):
    parsed = urlparse(url)
    return parsed._replace(fragment="").geturl()


def same_domain(base_url, target_url):
    base = urlparse(base_url)
    target = urlparse(target_url)
    return target.netloc == base.netloc


def classify_endpoint(url, source="discovery", external=False):
    if external:
        return EndpointType.EXTERNAL
    if source == "html.form":
        return EndpointType.FORM

    path = urlparse(url).path.lower()
    static_extensions = (
        ".avif", ".css", ".gif", ".ico", ".jpeg", ".jpg", ".js", ".png",
        ".svg", ".webp", ".woff", ".woff2", ".ttf", ".eot", ".map",
    )
    document_extensions = (".csv", ".doc", ".docx", ".pdf", ".ppt", ".txt", ".xls", ".xlsx")

    if path.endswith(static_extensions) or path.endswith("/favicon"):
        return EndpointType.STATIC
    if path.endswith(document_extensions):
        return EndpointType.DOCUMENT
    if source == "well-known":
        return EndpointType.RESOURCE
    if source.startswith("javascript.") or source == "html.route":
        return EndpointType.API
    if source in {"html.link", "sitemap", "query-string"}:
        return EndpointType.PAGE
    return EndpointType.UNKNOWN


def extract_metadata_urls(base_url, content):
    urls = set()
    # robots.txt Allow/Disallow express crawl rules, not permission to probe.
    path = urlparse(base_url).path.lower()
    if path.endswith("/robots.txt"):
        for match in re.findall(r"^\s*Sitemap:\s*([^\s#]+)", content, re.I | re.M):
            urls.add(urljoin(base_url, match))
    elif path.endswith(".xml"):
        for match in re.findall(r"<(?:[\w.-]+:)?loc>\s*(.*?)\s*</(?:[\w.-]+:)?loc>", content, re.I | re.S):
            urls.add(urljoin(base_url, match.strip()))
    if urlparse(base_url).path.lower().endswith("manifest.json"):
        try:
            manifest = json.loads(content)
        except (TypeError, ValueError):
            manifest = {}

        def collect_manifest_routes(value):
            if isinstance(value, dict):
                for key, child in value.items():
                    if key in {"start_url", "scope", "src", "url"} and isinstance(child, str):
                        urls.add(urljoin(base_url, child))
                    else:
                        collect_manifest_routes(child)
            elif isinstance(value, list):
                for child in value:
                    collect_manifest_routes(child)

        collect_manifest_routes(manifest)
    return sorted(urls)


def extract_route_candidates_from_html(html, base_url):
    candidates = set()
    soup = BeautifulSoup(html, "html.parser")

    for tag in soup.find_all(["a", "link", "script"]):
        value = tag.get("href") or tag.get("src")
        if not value:
            continue
        if value.startswith(("http://", "https://", "mailto:", "tel:")):
            continue
        candidates.add(urljoin(base_url, value))

    return sorted(candidates)


def extract_sitemap_urls(base_url, requester):
    urls = set()
    sitemap_candidates = [
        urljoin(base_url, "/robots.txt"),
        urljoin(base_url, "/sitemap.xml"),
        urljoin(base_url, "/manifest.json"),
    ]

    for url in sitemap_candidates:
        try:
            response = requester["get"](url)
            if response.status_code != 200:
                continue
            urls.add(url)
            text = response.text
            urls.update(extract_metadata_urls(url, text))
        except Exception:
            continue

    return sorted(urls)


def discover(start_url, requester, *, max_pages=MAX_PAGES):
    visited = set()
    queue = [start_url]

    pages = []
    forms = []
    endpoints = {}

    # Optional transport callbacks; supports existing injected requester fixtures.
    in_scope = requester.get("in_scope", lambda url: same_domain(start_url, url))
    budget_exhausted = requester.get("budget_exhausted", lambda: False)

    def add_endpoint(
        url,
        method="GET",
        source="unknown",
        confidence="medium",
        external=False,
        params=None,
        location="",
        detail="",
    ):
        value = normalize_url(url)
        if not is_valid_discovered_url(value):
            return
        parsed_value = urlparse(value)
        query_params = [
            Parameter(name=name, location="query")
            for name in parse_qs(parsed_value.query, keep_blank_values=True)
        ]
        value = urlunparse(parsed_value._replace(query="", fragment=""))
        params = query_params + (params or [])
        key = (method.upper(), value)
        endpoint = endpoints.get(key)
        if endpoint is None:
            endpoint = Endpoint(
                url=value,
                method=method.upper(),
                external=external,
                type=classify_endpoint(value, source=source, external=external),
            )
            endpoints[key] = endpoint

        if not (
            source == "html.route"
            and any(item.source == "well-known" for item in endpoint.evidence)
        ):
            endpoint.add_evidence(
                DiscoveryEvidence(
                    source=source,
                    confidence=confidence,
                    location=location,
                    detail=detail,
                )
            )
        endpoint.external = endpoint.external or external
        if endpoint.external:
            endpoint.type = EndpointType.EXTERNAL
        elif endpoint.type == EndpointType.UNKNOWN:
            endpoint.type = classify_endpoint(value, source=source, external=external)
        elif source == "html.form":
            endpoint.type = EndpointType.FORM
        for parameter in params or []:
            endpoint.add_parameter(parameter)

    metadata_urls = extract_sitemap_urls(start_url, requester)
    for metadata_url in metadata_urls:
        add_endpoint(
            metadata_url,
            method="GET",
            source="well-known",
            confidence="high",
            location=metadata_url,
            detail="well-known resource",
            external=not in_scope(metadata_url),
        )
        if in_scope(metadata_url):
            queue.append(metadata_url)

    while queue and len(visited) < max_pages and not budget_exhausted():
        current_url = normalize_url(queue.pop(0))
        if not in_scope(current_url):
            continue

        if current_url in visited:
            continue

        visited.add(current_url)

        try:
            response = requester["get"](current_url)
        except Exception as error:
            print(f"[?] Discovery error: {current_url} -> {error}")
            continue

        content_type = response.headers.get("Content-Type", "")
        pages.append(
            Page(
                url=current_url,
                status_code=response.status_code,
                content_type=content_type,
                size=len(response.content),
                http_observation=analyze_response(response),
            )
        )

        print(
            f"[DISCOVERY] {response.status_code} "
            f"{len(response.content):>7} bytes {current_url}"
        )

        parsed = urlparse(current_url)
        query_params = parse_qs(parsed.query, keep_blank_values=True)
        if query_params:
            add_endpoint(
                current_url,
                method="GET",
                source="query-string",
                confidence="high",
                location=current_url,
                detail="URL query string",
                params=[Parameter(name=name, location="query") for name in query_params],
            )

        if "text/html" in content_type.lower():
            soup = BeautifulSoup(response.text, "html.parser")

            for anchor in soup.find_all("a", href=True):
                href = anchor["href"]
                absolute = normalize_url(urljoin(current_url, href))
                parsed_link = urlparse(absolute)

                if parsed_link.scheme not in ("http", "https"):
                    continue

                if SAME_DOMAIN_ONLY and not in_scope(absolute):
                    continue

                if absolute not in visited:
                    queue.append(absolute)

                add_endpoint(
                    absolute,
                    method="GET",
                    source="html.link",
                    confidence="high",
                    location=current_url,
                    detail="HTML anchor",
                    external=not in_scope(absolute),
                    params=[
                        Parameter(name=name, location="query")
                        for name in parse_qs(urlparse(absolute).query, keep_blank_values=True)
                    ],
                )

            for form in soup.find_all("form"):
                action = form.get("action") or current_url
                action = urljoin(current_url, action)
                method = form.get("method", "GET").upper()
                is_external = not in_scope(action)
                fields = []

                for field in form.find_all(["input", "textarea", "select"]):
                    name = field.get("name")
                    if not name:
                        continue

                    input_type = field.get("type", field.name)
                    fields.append(Field(name=name, input_type=input_type))

                if fields:
                    forms.append(
                        Form(
                            action=action,
                            method=method,
                            external=is_external,
                            fields=fields,
                        )
                    )
                    add_endpoint(
                        action,
                        method=method,
                        source="html.form",
                        confidence="high",
                        location=current_url,
                        detail="HTML form",
                        external=is_external,
                        params=[
                            Parameter(
                                name=field.name,
                                location="query" if method == "GET" else "body",
                                input_type=field.input_type,
                            )
                            for field in fields
                        ],
                    )

            for route in extract_route_candidates_from_html(response.text, current_url):
                route_internal = in_scope(route)
                if not route_internal and SAME_DOMAIN_ONLY:
                    continue
                add_endpoint(
                    route,
                    method="GET",
                    source="html.route",
                    confidence="medium",
                    location=current_url,
                    detail="HTML route candidate",
                    external=not route_internal,
                    params=[
                        Parameter(name=name, location="query")
                        for name in parse_qs(urlparse(route).query, keep_blank_values=True)
                    ],
                )

            for js_src in [tag.get("src") for tag in soup.find_all("script") if tag.get("src")]:
                js_url = urljoin(current_url, js_src)
                if not in_scope(js_url) or budget_exhausted():
                    continue
                try:
                    js_response = requester["get"](js_url)
                    for route, javascript_source in extract_js_route_candidates_with_sources(js_response.text):
                        if not is_valid_js_route(route):
                            continue
                        full_url = urljoin(js_url, route)
                        full_url = normalize_url(full_url)
                        route_internal = in_scope(full_url)
                        if SAME_DOMAIN_ONLY and not route_internal:
                            continue
                        add_endpoint(
                            full_url,
                            method="GET",
                            source=javascript_source,
                            confidence="high",
                            location=js_url,
                            detail="application JavaScript",
                            external=not route_internal,
                            params=[
                                Parameter(name=name, location="query")
                                for name in parse_qs(urlparse(full_url).query, keep_blank_values=True)
                            ],
                        )
                except Exception:
                    continue

            for script in soup.find_all("script"):
                if script.get("src"):
                    continue
                for route, javascript_source in extract_js_route_candidates_with_sources(
                    script.string or script.get_text()
                ):
                    if not is_valid_js_route(route):
                        continue
                    full_url = normalize_url(urljoin(current_url, route))
                    route_internal = in_scope(full_url)
                    if SAME_DOMAIN_ONLY and not route_internal:
                        continue
                    add_endpoint(
                        full_url,
                        method="GET",
                        source=javascript_source,
                        confidence="high",
                        location=current_url,
                        detail="inline JavaScript",
                        external=not route_internal,
                        params=[
                            Parameter(name=name, location="query")
                            for name in parse_qs(urlparse(full_url).query, keep_blank_values=True)
                        ],
                    )

    page_observations = {page.url: page.http_observation for page in pages}
    for endpoint in endpoints.values():
        if endpoint.url in page_observations:
            endpoint.http_observation = page_observations[endpoint.url]
            endpoint.http_observation_reason = "already fetched during discovery"
            continue

        if endpoint.method != "GET":
            endpoint.http_observation_reason = "not requested: non-GET endpoint"
            continue
        if endpoint.external or not in_scope(endpoint.url):
            endpoint.http_observation_reason = "not requested: out-of-scope endpoint"
            continue
        if budget_exhausted():
            endpoint.http_observation_reason = "not requested: request budget exhausted"
            continue
        if endpoint.parameters:
            endpoint.http_observation_reason = "not requested: parameterized endpoint"
            continue

        try:
            response = requester["get"](endpoint.url)
            endpoint.http_observation = analyze_response(response)
            endpoint.http_observation_reason = "requested passively"
        except Exception as error:
            endpoint.http_observation_reason = f"not requested: {error}"

    return pages, forms, list(endpoints.values())
